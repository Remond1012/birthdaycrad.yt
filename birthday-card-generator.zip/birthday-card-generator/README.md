# Birthday card generator

A Pen created on CodePen.io. Original URL: [https://codepen.io/flaviocopes/pen/VweMMBZ](https://codepen.io/flaviocopes/pen/VweMMBZ).

